/* ============================================================
   GITHUB CONFIG — fill these two lines in after you create your
   GitHub repo, then this file works for BOTH index.html (reading
   live data) and admin.html (writing new data). No Firebase, no
   card, no other backend — GitHub itself is the database.
   ============================================================ */
const GITHUB_OWNER  = "";   // your GitHub username, e.g. "eooapninotes"
const GITHUB_REPO   = "";   // your repo name, e.g. "apninotes-website"
const GITHUB_BRANCH = "main";

const GITHUB_READY = !!(GITHUB_OWNER && GITHUB_REPO);
